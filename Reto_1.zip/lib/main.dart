import 'package:flutter/material.dart';
import 'package:parcial/src/my_app.dart';

void main() => runApp(const MyApp());
